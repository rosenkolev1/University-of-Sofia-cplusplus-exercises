﻿// Zada4a5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

int main()
{
	for (int i = 0; i < 5; i++)
	{
		for (int y = 0; y < 4; y++)
		{
			cout << "* ";
		}
		cout << endl;
	}
}

